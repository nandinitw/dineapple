<?php
namespace App\Http\Controllers;

use Auth;
use DB;
use Illuminate\Routing\Controller;
use App\Models\User;

class AuthController extends Controller {

    



}
