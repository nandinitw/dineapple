<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RatingsOutlets extends Model
{
    protected $fillable = ['rating_id','outlet_id ','state'];

    // public function getAssignedRatings($outlet_id){

       

    // }
    
}
